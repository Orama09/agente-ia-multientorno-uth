"use client";

import Link from "next/link";
import { GraduationCap } from "lucide-react";

export default function Navbar() {
  return (
    <nav className="w-full fixed top-0 left-0 z-50 backdrop-blur-md bg-black/40 border-b border-white/10 flex items-center">

      {/* Aumentamos py a py-7 para dar más espacio vertical */}
      <div className="max-w-7xl mx-auto px-8 py-7 flex justify-between items-center text-white w-full">

        {/* LOGO */}
        <div className="flex items-center gap-3 font-extrabold text-3xl tracking-wide">
          <GraduationCap className="text-[#C5A853]" size={40} />
          UTH
        </div>

        {/* MENÚ */}
        <div className="hidden md:flex gap-12 text-xl font-bold">

          <Link
            href="/"
            className="hover:text-[#E5D6A0] transition duration-300"
          >
            Inicio
          </Link>

          <Link
            href="/acerca"
            className="hover:text-[#E5D6A0] transition duration-300"
          >
            Acerca de UTH
          </Link>

          <Link
            href="/estudiantes"
            className="hover:text-[#E5D6A0] transition duration-300"
          >
            Estudiantes
          </Link>

          <Link
            href="/oferta-academica"
            className="hover:text-[#E5D6A0] transition duration-300"
          >
            Oferta Académica
          </Link>

        </div>
      </div>
    </nav>
  );
}