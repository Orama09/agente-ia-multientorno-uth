"use client";

import {
  Component,
  Suspense,
  useState,
  type ErrorInfo,
  type ReactNode,
} from "react";
import { Canvas } from "@react-three/fiber";
import { ContactShadows, Html } from "@react-three/drei";
import type { AvatarState } from "@/types/avatar";
import {
  AVATAR_3D_AMBIENT_INTENSITY,
  AVATAR_3D_CAMERA_FOV,
  AVATAR_3D_CAMERA_POSITION,
  AVATAR_3D_CAMERA_TARGET,
  AVATAR_3D_FILL_LIGHT,
  AVATAR_3D_KEY_LIGHT,
  AVATAR_3D_SHADOW_POSITION,
} from "@/lib/avatar/avatar3DConfig";
import Avatar3DModel from "./Avatar3DModel";
import Avatar3DOrbitControls from "./Avatar3DOrbitControls";

type Avatar3DPanelProps = {
  avatarState?: AvatarState;
  showStatusLabel?: boolean;
  /** Si falla la carga WebGL/GLB, el padre debe mostrar un estado alterno. */
  onFatalError?: (error?: unknown) => void;
};

/** 🔧 Contenedor visual del escenario 3D */
function StageShell({ children }: { children: ReactNode }) {
  return (
    // 1. Alto del contenedor — REDUCIDO respecto a la versión anterior
    // (450px/400px → 340px/300px). Esto ya NO achica al avatar porque la
    // cámara en avatar3DConfig.ts se acercó/hizo zoom para compensar
    // (encuadre de busto en vez de cuerpo completo) — ver ese archivo.
    <div className="relative w-full h-[340px] sm:h-[300px] flex items-center justify-center overflow-hidden bg-transparent">
      {/* 2. Círculo dorado de fondo */}
      {/* Recalculado para la nueva caja más chica (340px/300px) — mismo
          tamaño de círculo (280px/300px), centrado con margen para el
          título/logo arriba. */}
      <div className="absolute w-[280px] h-[280px] sm:w-[300px] sm:h-[300px] rounded-full bg-[#C5A853] top-[48%] sm:top-[58%] left-1/2 -translate-x-1/2 -translate-y-1/2 z-0 shadow-lg" />

      {/* 3. LADO IZQUIERDO: Título + Subtítulo */}
      {/* 🔼 SUBIDO: antes top-[20px] sm:top-[110px] — ese sm:110px era el
          principal causante del hueco vacío arriba. Ahora top-4 (16px) fijo
          en todos los tamaños. */}
      <div className="absolute top-4 left-2 flex flex-col items-start z-20">
        {/* 🟡 TAMAÑO DEL TEXTO: Aumentamos en pantallas chicas (text-base), mantenemos chico en sm (text-xs) */}
        <h2 className="text-base sm:text-xs font-black text-gray-800 tracking-wider uppercase text-left leading-none">
          ASISTENTE VIRTUAL
        </h2>
        <p className="text-xs sm:text-xs text-gray-600 font-semibold mt-1">
          Listo para ayudarte
        </p>
      </div>

      {/* 4. LADO DERECHO: Logo UTH */}
      {/* 🔼 SUBIDO: mismo motivo que el título de arriba. */}
      <div className="absolute top-[-8px] right-2 flex flex-col items-end z-20">
        {/* 🟡 TAMAÑO DEL LOGO: Aumentamos en pantallas chicas (h-12), mantenemos chico en sm (h-9) */}
        <img
          src="/images/logo_uth.png"
          alt="Logo UTH"
          className="h-30 sm:h-28 w-auto object-contain"
        />
      </div>

      {/* Canvas 3D a pantalla completa sobre el círculo */}
      <div className="relative w-full h-full z-10 translate-x-5">
        {children}
      </div>
    </div>
  );
}



function CanvasLoader() {
  return (
    <Html center>
      <div className="h-9 w-9 rounded-full border-2 border-white border-t-transparent animate-spin" />
    </Html>
  );
}

type BoundaryProps = {
  onError?: (error: Error) => void;
  fallback: ReactNode;
  children: ReactNode;
};

type BoundaryState = { hasError: boolean };

class Avatar3DErrorBoundary extends Component<BoundaryProps, BoundaryState> {
  state: BoundaryState = { hasError: false };

  static getDerivedStateFromError(): BoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: Error, _info: ErrorInfo) {
    if (process.env.NODE_ENV === "development") {
      console.error("[Avatar3DPanel] Fallo al renderizar avatar 3D:", error);
    }
    this.props.onError?.(error);
  }

  render() {
    if (this.state.hasError) return this.props.fallback;
    return this.props.children;
  }
}

/**
 * Renderer experimental threejs.
 * Recibe solo `avatarState` como prop de entrada.
 * Debe cargarse con dynamic(..., { ssr: false }).
 */
export default function Avatar3DPanel({
  avatarState = "idle",
  showStatusLabel = false,
  onFatalError,
}: Avatar3DPanelProps) {

  // 👇 Detecta si el mouse está sobre el panel del avatar (todo el
  // escenario, incluida la zona del canvas). Se pasa al modelo 3D para
  // que reaccione (seguir el cursor, animaciones extra, etc).
  const [isHovered, setIsHovered] = useState(false);

  return (
    <section
      className="w-full mx-auto"
      aria-label="Escenario 3D del avatar del asistente"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <StageShell>
        <Avatar3DErrorBoundary
          onError={(error) => onFatalError?.(error)}
          fallback={
            <div className="absolute inset-0 flex items-center justify-center px-3 text-center">
              <p className="text-xs text-white">
                No se pudo cargar el avatar 3D
              </p>
            </div>
          }
        >
          <Canvas
            className="w-full h-full touch-none"
            camera={{
              position: [...AVATAR_3D_CAMERA_POSITION],
              fov: AVATAR_3D_CAMERA_FOV,
              near: 0.1,
              far: 50,
            }}
            dpr={[1, 1.75]}
            gl={{ antialias: true, alpha: true, powerPreference: "default" }}
            onCreated={({ gl, camera }) => {
              gl.setClearColor(0x000000, 0);
              camera.lookAt(
                AVATAR_3D_CAMERA_TARGET[0],
                AVATAR_3D_CAMERA_TARGET[1],
                AVATAR_3D_CAMERA_TARGET[2],
              );
            }}
          >
            <ambientLight intensity={AVATAR_3D_AMBIENT_INTENSITY} />
            <hemisphereLight
              intensity={0.35}
              color="#ffffff"
              groundColor="#e8eef0"
            />
            <directionalLight
              position={[...AVATAR_3D_KEY_LIGHT.position]}
              intensity={AVATAR_3D_KEY_LIGHT.intensity}
            />
            <directionalLight
              position={[...AVATAR_3D_FILL_LIGHT.position]}
              intensity={AVATAR_3D_FILL_LIGHT.intensity}
            />

            <Suspense fallback={<CanvasLoader />}>
              <Avatar3DModel avatarState={avatarState} isHovered={isHovered} />
              <ContactShadows
                position={[...AVATAR_3D_SHADOW_POSITION]}
                opacity={0.28}
                scale={5}
                blur={2.2}
                far={2.5}
              />
            </Suspense>

            <Avatar3DOrbitControls />
          </Canvas>
        </Avatar3DErrorBoundary>
      </StageShell>
    </section>
  );
}
